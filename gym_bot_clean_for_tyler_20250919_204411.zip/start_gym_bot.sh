#!/bin/bash
echo "Setting up Gym Bot for Tyler..."
python3 setup_for_tyler.py
echo ""
echo "Setup complete! Starting the app..."
echo "NOTE: Internet connection required for ClubOS/ClubHub"
echo ""
python3 start_gym_bot.py
