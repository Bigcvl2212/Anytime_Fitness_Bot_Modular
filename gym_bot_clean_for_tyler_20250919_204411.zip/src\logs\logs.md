Most active in AugustINFO:src.routes.messaging:🔍 Database table check: members table exists = True

INFO:src.routes.messaging:🔍 Raw database query results: 10 rows

INFO:src.routes.messaging:  Row 1: status\_message='Member is in good standing', count=314

INFO:src.routes.messaging:  Row 2: status\_message='Pay per visit member', count=116

INFO:src.routes.messaging:  Row 3: status\_message='Staff member', count=29    

INFO:src.routes.messaging:  Row 4: status\_message='Comp member', count=27     

INFO:src.routes.messaging:  Row 5: status\_message='Past Due more than 30 days.', count=15

INFO:src.routes.messaging:✅ Retrieved 10 real ClubHub status categories      

INFO:werkzeug:172.16.100.156 - - \[09/Sep/2025 11:36:50] "GET /api/members/categories HTTP/1.1" 200 -

INFO:src.routes.messaging:📨 Campaign send request received: {'name': '9.9', 'message': "Don't just date fitness, fall in love with it this fall! Our unlimited training plans include up to 5x/week training, nutrition coaching, body scans, and access to a hot tub and pool. Get it all for just $74.99 biweekly for group or $124.99 biweekly for 1-on-1 coaching. DON'T SLEEP ON THIS!!", 'type': 'sms', 'categories': \['prospects'], 'max\_recipients': 5, 'notes': 'Jeremy 9.9'}

INFO:src.routes.messaging:📋 Campaign params - Message: 'Don't just date fitness, fall in love with it this...', Type: sms, Categories: \['prospects'], Max: 5

INFO:src.routes.messaging:📝 Campaign notes: 'Jeremy 9.9...'

INFO:src.routes.messaging:🔍 Processing category: 'prospects'

INFO:src.routes.messaging:📍 Starting prospects from beginning (no previous progress)

INFO:src.routes.messaging:📊 Selecting prospects

INFO:src.routes.messaging:📋 Found 5 members for category 'prospects'

INFO:src.routes.messaging:📊 Total validated members selected: 5

INFO:src.routes.messaging:🔄 Initializing ClubOS messaging client...

INFO:src.routes.messaging:🔐 Authenticating with ClubOS...

INFO:src.services.clubos\_messaging\_client\_simple:🔐 Authenticating j.mayo using HAR sequence

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Extracted form fields successfully

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Extracted club ID: 291

INFO:src.services.clubos\_messaging\_client\_simple:✅ Authentication successful - User ID: 187032782

INFO:src.routes.messaging:✅ ClubOS authentication successful, sending campaign...

INFO:src.services.clubos\_messaging\_client\_simple:📢 Starting bulk campaign to 5 members

INFO:src.services.clubos\_messaging\_client\_simple:📨 Sending message 1/5 to Zachary Kollmann (ID: 10061388)

INFO:src.services.clubos\_messaging\_client\_simple:📱 Sending sms message to member 10061388: 'Don't just date fitness, fall in love with it this...'

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Getting CSRF token from FollowUp form page...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Tokens from FollowUp page - CSRF: False, FP: False

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Fallback: trying dashboard for tokens...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Tokens from dashboard - CSRF: False (length: 0)

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No CSRF token found anyywhere - proceeding without it (might work)

WARNING:src.services.clubos\_messaging\_client\_simple:This could be because ClubOS uses JavaScript-generated tokens or session-based auth

INFO:src.services.clubos\_messaging\_client\_simple:📞 Normalized phone: 920-266-7040 -> +19202667040

INFO:src.services.clubos\_messaging\_client\_simple:📤 Posting to FollowUp form with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ FollowUp form received

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No fresh CSRF token froom FollowUp form - proceeding with session auth

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using member data: {'member\_id': '10061388', 'prospect\_id': '10061388', 'email': 'KollmZ35@uwosh.edu', 'mobile\_phone': '920-266-7040', 'full\_name': 'Zachary Kollmann', 'status\_message': '0', 'mobilePhone': '+19202667040', 'firstName': 'Zachary', 'lastName': 'Kollmann'}

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using CSRF token: ... (length: 0)

INFO:src.services.clubos\_messaging\_client\_simple:📤 Submitting message with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:📄 Full response: <br />Something isn't right.  Please refresh the page and try your request again.<br />  

ERROR:src.services.clubos\_messaging\_client\_simple:❌ ClubOS error: 'Something isn't right' - likely CSRF token or field mapping issue

ERROR:src.services.clubos\_messaging\_client\_simple:CSRF token used: ...        

ERROR:src.services.clubos\_messaging\_client\_simple:❌ Failed to send to Zachary Kollmann (ID: 10061388)

INFO:src.services.clubos\_messaging\_client\_simple:📨 Sending message 2/5 to Elizabeth Rawlins (ID: 10081314)

INFO:src.services.clubos\_messaging\_client\_simple:📱 Sending sms message to member 10081314: 'Don't just date fitness, fall in love with it this...'

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Getting CSRF token from FollowUp form page...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Tokens from FollowUp page - CSRF: False, FP: False

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Fallback: trying dashboard for tokens...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Tokens from dashboard - CSRF: False (length: 0)

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No CSRF token found anyywhere - proceeding without it (might work)

WARNING:src.services.clubos\_messaging\_client\_simple:This could be because ClubOS uses JavaScript-generated tokens or session-based auth

INFO:src.services.clubos\_messaging\_client\_simple:📞 Normalized phone: 9205390821 -> +19205390821

INFO:src.services.clubos\_messaging\_client\_simple:📤 Posting to FollowUp form with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ FollowUp form received

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No fresh CSRF token froom FollowUp form - proceeding with session auth

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using member data: {'member\_id': '10081314', 'prospect\_id': '10081314', 'email': 'erawlins@student.morainepark.edu', 'mobile\_phone': '9205390821', 'full\_name': 'Elizabeth Rawlins', 'status\_message': '0', 'mobilePhone': '+19205390821', 'firstName': 'Elizabeth', 'lastName': 'Rawlins'}

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using CSRF token: ... (length: 0)

INFO:src.services.clubos\_messaging\_client\_simple:📤 Submitting message with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:📄 Full response: <br />Something isn't right.  Please refresh the page and try your request again.<br />  

ERROR:src.services.clubos\_messaging\_client\_simple:❌ ClubOS error: 'Something isn't right' - likely CSRF token or field mapping issue

ERROR:src.services.clubos\_messaging\_client\_simple:CSRF token used: ...        

ERROR:src.services.clubos\_messaging\_client\_simple:❌ Failed to send to Elizabeth Rawlins (ID: 10081314)

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ 2 consecutive failures,, re-authenticating...

INFO:src.services.clubos\_messaging\_client\_simple:🔐 Authenticating j.mayo using HAR sequence

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Extracted form fields successfully

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Extracted club ID: 291

INFO:src.services.clubos\_messaging\_client\_simple:✅ Authentication successful - User ID: 187032782

INFO:src.services.clubos\_messaging\_client\_simple:✅ Re-authentication successful

INFO:src.services.clubos\_messaging\_client\_simple:📨 Sending message 3/5 to Stephanie Xiong (ID: 10098662)

INFO:src.services.clubos\_messaging\_client\_simple:📱 Sending sms message to member 10098662: 'Don't just date fitness, fall in love with it this...'

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Getting CSRF token from FollowUp form page...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Tokens from FollowUp page - CSRF: False, FP: False

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Fallback: trying dashboard for tokens...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Tokens from dashboard - CSRF: False (length: 0)

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No CSRF token found anyywhere - proceeding without it (might work)

WARNING:src.services.clubos\_messaging\_client\_simple:This could be because ClubOS uses JavaScript-generated tokens or session-based auth

INFO:src.services.clubos\_messaging\_client\_simple:📞 Normalized phone: 9209339580 -> +19209339580

INFO:src.services.clubos\_messaging\_client\_simple:📤 Posting to FollowUp form with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ FollowUp form received

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No fresh CSRF token froom FollowUp form - proceeding with session auth

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using member data: {'member\_id': '10098662', 'prospect\_id': '10098662', 'email': 'pakouxiong93@gmail.com', 'mobile\_phone': '9209339580', 'full\_name': 'Stephanie Xiong', 'status\_message': '0', 'mobilePhone': '+19209339580', 'firstName': 'Stephanie', 'lastName': 'Xiong'}

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using CSRF token: ... (length: 0)

INFO:src.services.clubos\_messaging\_client\_simple:📤 Submitting message with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:📄 Full response: <br />Something isn't right.  Please refresh the page and try your request again.<br />  

ERROR:src.services.clubos\_messaging\_client\_simple:❌ ClubOS error: 'Something isn't right' - likely CSRF token or field mapping issue

ERROR:src.services.clubos\_messaging\_client\_simple:CSRF token used: ...        

ERROR:src.services.clubos\_messaging\_client\_simple:❌ Failed to send to Stephanie Xiong (ID: 10098662)

INFO:src.services.clubos\_messaging\_client\_simple:📨 Sending message 4/5 to Keanna Otto (ID: 10147729)

INFO:src.services.clubos\_messaging\_client\_simple:📱 Sending sms message to member 10147729: 'Don't just date fitness, fall in love with it this...'

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Getting CSRF token from FollowUp form page...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Tokens from FollowUp page - CSRF: False, FP: False

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Fallback: trying dashboard for tokens...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Tokens from dashboard - CSRF: False (length: 0)

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No CSRF token found anyywhere - proceeding without it (might work)

WARNING:src.services.clubos\_messaging\_client\_simple:This could be because ClubOS uses JavaScript-generated tokens or session-based auth

INFO:src.services.clubos\_messaging\_client\_simple:📞 Normalized phone: (262)305-1869 -> +12623051869

INFO:src.services.clubos\_messaging\_client\_simple:📤 Posting to FollowUp form with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ FollowUp form received

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No fresh CSRF token froom FollowUp form - proceeding with session auth

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using member data: {'member\_id': '10147729', 'prospect\_id': '10147729', 'email': 'Kotto9.2@gmail.com', 'mobile\_phone': '(262)305-1869', 'full\_name': 'Keanna Otto', 'status\_message': '0', 'mobilePhone': '+12623051869', 'firstName': 'Keanna', 'lastName': 'Otto'}

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using CSRF token: ... (length: 0)

INFO:src.services.clubos\_messaging\_client\_simple:📤 Submitting message with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:📄 Full response: <br />Something isn't right.  Please refresh the page and try your request again.<br />  

ERROR:src.services.clubos\_messaging\_client\_simple:❌ ClubOS error: 'Something isn't right' - likely CSRF token or field mapping issue

ERROR:src.services.clubos\_messaging\_client\_simple:CSRF token used: ...        

ERROR:src.services.clubos\_messaging\_client\_simple:❌ Failed to send to Keanna Otto (ID: 10147729)

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ 2 consecutive failures,, re-authenticating...

INFO:src.services.clubos\_messaging\_client\_simple:🔐 Authenticating j.mayo using HAR sequence

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Extracted form fields successfully

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Extracted club ID: 291

INFO:src.services.clubos\_messaging\_client\_simple:✅ Authentication successful - User ID: 187032782

INFO:src.services.clubos\_messaging\_client\_simple:✅ Re-authentication successful

INFO:src.services.clubos\_messaging\_client\_simple:📨 Sending message 5/5 to Steven Shaw (ID: 10154249)

INFO:src.services.clubos\_messaging\_client\_simple:📱 Sending sms message to member 10154249: 'Don't just date fitness, fall in love with it this...'

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Getting CSRF token from FollowUp form page...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ Tokens from FollowUp page - CSRF: False, FP: False

INFO:src.services.clubos\_messaging\_client\_simple:🔍 Fallback: trying dashboard for tokens...

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:Tokens from dashboard - CSRF: False (length: 0)

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No CSRF token found anyywhere - proceeding without it (might work)

WARNING:src.services.clubos\_messaging\_client\_simple:This could be because ClubOS uses JavaScript-generated tokens or session-based auth

INFO:src.services.clubos\_messaging\_client\_simple:📞 Normalized phone: 9209216237 -> +19209216237

INFO:src.services.clubos\_messaging\_client\_simple:📤 Posting to FollowUp form with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:✅ FollowUp form received

WARNING:src.services.clubos\_messaging\_client\_simple:⚠️ No fresh CSRF token froom FollowUp form - proceeding with session auth

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using member data: {'member\_id': '10154249', 'prospect\_id': '10154249', 'email': 'contact@muscleandbrawn.com', 'mobile\_phone': '9209216237', 'full\_name': 'Steven Shaw', 'status\_message': '0', 'mobilePhone': '+19209216237', 'firstName': 'Steven', 'lastName': 'Shaw'}

INFO:src.services.clubos\_messaging\_client\_simple:✅ Using CSRF token: ... (length: 0)

INFO:src.services.clubos\_messaging\_client\_simple:📤 Submitting message with CSRF token: False

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

C:\\Users\\mayoj\\OneDrive\\Documents\\Gym-Bot\\gym-bot\\gym-bot-modular\\.venv\\Lib\\site-packages\\urllib3\\connectionpool.py:1097: InsecureRequestWarning: Unverified HTTPS request is being made to host 'anytime.club-os.com'. Adding certificate verification is strongly advised. See: https://urllib3.readthedocs.io/en/latest/advanced-usage.html#tls-warnings

&nbsp; warnings.warn(

INFO:src.services.clubos\_messaging\_client\_simple:📄 Full response: <br />Something isn't right.  Please refresh the page and try your request again.<br />  

ERROR:src.services.clubos\_messaging\_client\_simple:❌ ClubOS error: 'Something isn't right' - likely CSRF token or field mapping issue

ERROR:src.services.clubos\_messaging\_client\_simple:CSRF token used: ...        

ERROR:src.services.clubos\_messaging\_client\_simple:❌ Failed to send to Steven Shaw (ID: 10154249)

INFO:src.services.clubos\_messaging\_client\_simple:📊 Campaign completed: 0/5 successful

INFO:src.routes.messaging:📢 Campaign completed: 0/5 sent successfully

INFO:werkzeug:172.16.100.156 - - \[09/Sep/2025 11:37:34] "POST /api/campaigns/send HTTP/1.1" 200 -

INFO:werkzeug:172.16.100.156 - - \[09/Sep/2025 11:37:34] "GET /api/campaigns/history HTTP/1.1" 200 -

INFO:werkzeug:172.16.100.156 - - \[09/Sep/2025 11:37:34] "GET /api/campaigns/progress HTTP/1.1" 200 -



