# ClubOS credentials for training clients integration
# These are dummy credentials since we're not using ClubOS integration currently

CLUBOS_USERNAME = ""
CLUBOS_PASSWORD = ""
