#!/bin/bash
echo "Starting Gym Bot Setup..."
python3 setup_for_tyler.py
echo ""
echo "Setup complete! Now starting the app..."
python3 start_gym_bot.py
