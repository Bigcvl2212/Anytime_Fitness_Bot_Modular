#!/usr/bin/env python3
"""
Configuration package for the Anytime Fitness Dashboard
"""

# This file makes the config directory a Python package
